# Bộ kiểm thử tự động (Jest) – Phần mềm tính tiền dạy (Nhóm 11)

## Nội dung
- `src/lib/payroll.ts` – các hàm logic thuần: tính tiền dạy, validate, sinh mã.
- `src/lib/__tests__/payroll.test.ts` – 26 unit test (Jest), gồm 3 ca kiểm chứng công thức bằng số liệu thật từ báo cáo.

## Cách chạy
```bash
npm install
npm test            # chạy test
npm run coverage    # chạy test + đo độ bao phủ
```

## Kết quả tham chiếu (đã chạy thật)
- Test Suites: 1 passed
- Tests: 26 passed / 26
- Coverage payroll.ts: 100% statements / 100% branch / 100% functions / 100% lines

> Trong dự án thật, đặt các file này vào `src/lib/` của ứng dụng Next.js và import logic
> từ tầng API (`teacher-payments/route.ts`) thay vì viết lại, để test đúng mã chạy production.
