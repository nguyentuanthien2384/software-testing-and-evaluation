/**
 * src/lib/payroll.ts (rút gọn cho mục đích kiểm thử đơn vị)
 * Logic thuần (pure functions) tách khỏi tầng API/CSDL để dễ unit test.
 */

export interface ClassPayInput {
  hours: number;          // số tiết thực dạy
  subjectCoef: number;    // hệ số học phần
  classCoef: number;      // hệ số lớp (theo sĩ số)
  rate: number;           // định mức tiền/tiết theo năm học (VND)
  degreeCoef: number;     // hệ số bằng cấp của giáo viên
}

/** Số tiết quy đổi = số tiết × (hệ số học phần + hệ số lớp). */
export function convertedHours(i: ClassPayInput): number {
  return i.hours * (i.subjectCoef + i.classCoef);
}

/** Tiền dạy 1 lớp = tiết quy đổi × định mức × hệ số bằng cấp (làm tròn về VND nguyên). */
export function classPayment(i: ClassPayInput): number {
  return Math.round(convertedHours(i) * i.rate * i.degreeCoef);
}

/** Tổng tiền dạy của 1 giáo viên trong 1 kỳ = tổng tiền các lớp. */
export function totalPayment(classes: ClassPayInput[]): number {
  if (!classes || classes.length === 0) {
    throw new Error("Không có dữ liệu.");
  }
  return classes.reduce((sum, c) => sum + classPayment(c), 0);
}

// ---- validators ----
export function validateEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export function validatePhoneVN(phone: string): boolean {
  return /^0\d{9}$/.test(phone);
}

/** Tuổi hợp lệ cho giáo viên: 22–70. */
export function validateTeacherAge(age: number): boolean {
  return Number.isFinite(age) && age >= 22 && age <= 70;
}

/** Hệ số phải > 0. */
export function validateCoefficient(c: number): boolean {
  return Number.isFinite(c) && c > 0;
}

/** Sinh mã giáo viên dạng GV0001 từ số thứ tự. */
export function genTeacherCode(seq: number): string {
  return "GV" + String(seq).padStart(4, "0");
}

/** Sinh mã lớp dạng <mãHP>.NN. */
export function genClassCode(subjectCode: string, index: number): string {
  return `${subjectCode}.${String(index).padStart(2, "0")}`;
}
