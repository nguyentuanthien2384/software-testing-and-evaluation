/**
 * src/lib/__tests__/payroll.test.ts
 * Unit test (Jest) cho logic tính tiền dạy và các hàm validate.
 * Chạy: npm test   /   npx jest   /   npx jest --coverage
 */
import {
  convertedHours, classPayment, totalPayment,
  validateEmail, validatePhoneVN, validateTeacherAge,
  validateCoefficient, genTeacherCode, genClassCode,
} from "../payroll";

describe("Công thức tính tiền dạy (số liệu thật từ báo cáo Nhóm 11)", () => {
  test("CALC001 – Bùi Thị Hoa, Mạch điện tử L53: 45 tiết, HP=1, lớp=-0.1, ĐM=143k, BC=2", () => {
    const i = { hours: 45, subjectCoef: 1, classCoef: -0.1, rate: 143000, degreeCoef: 2 };
    expect(convertedHours(i)).toBeCloseTo(40.5);
    expect(classPayment(i)).toBe(11583000);
  });

  test("CALC002 – Cấu trúc DL L02: 60 tiết, HP=1.2, lớp=-0.1, ĐM=143k, BC=2", () => {
    const i = { hours: 60, subjectCoef: 1.2, classCoef: -0.1, rate: 143000, degreeCoef: 2 };
    expect(convertedHours(i)).toBeCloseTo(66);
    expect(classPayment(i)).toBe(18876000);
  });

  test("CALC003 – Trần Thị Bình: 45 tiết, HP=1, lớp=0, ĐM=143k, BC=2", () => {
    const i = { hours: 45, subjectCoef: 1, classCoef: 0, rate: 143000, degreeCoef: 2 };
    expect(classPayment(i)).toBe(12870000);
  });

  test("Tổng tiền 1 kỳ của Bùi Thị Hoa (2 lớp) = 30.459.000", () => {
    const total = totalPayment([
      { hours: 45, subjectCoef: 1, classCoef: -0.1, rate: 143000, degreeCoef: 2 },
      { hours: 60, subjectCoef: 1.2, classCoef: -0.1, rate: 143000, degreeCoef: 2 },
    ]);
    expect(total).toBe(30459000);
  });

  test("Không có lớp nào → ném lỗi 'Không có dữ liệu.'", () => {
    expect(() => totalPayment([])).toThrow("Không có dữ liệu.");
  });
});

describe("Validate Email", () => {
  test.each([
    ["abc@example.com", true],
    ["a.b@uni.edu.vn", true],
    ["abc@", false],
    ["abc.com", false],
    ["", false],
  ])("'%s' → %s", (input, expected) => {
    expect(validateEmail(input as string)).toBe(expected);
  });
});

describe("Validate số điện thoại VN (10 số, bắt đầu 0)", () => {
  test("hợp lệ", () => expect(validatePhoneVN("0329110240")).toBe(true));
  test("thiếu số", () => expect(validatePhoneVN("032911024")).toBe(false));
  test("sai đầu số", () => expect(validatePhoneVN("1329110240")).toBe(false));
  test("chứa chữ", () => expect(validatePhoneVN("03291102ab")).toBe(false));
});

describe("Validate tuổi giáo viên (22–70)", () => {
  test.each([[22, true], [70, true], [45, true], [21, false], [71, false], [NaN, false]])(
    "tuổi %s → %s", (age, ok) => expect(validateTeacherAge(age as number)).toBe(ok)
  );
});

describe("Validate hệ số (> 0)", () => {
  test("hệ số 1.2 hợp lệ", () => expect(validateCoefficient(1.2)).toBe(true));
  test("hệ số 0 không hợp lệ", () => expect(validateCoefficient(0)).toBe(false));
  test("hệ số âm không hợp lệ", () => expect(validateCoefficient(-1)).toBe(false));
});

describe("Sinh mã tự động", () => {
  test("mã giáo viên GV0001", () => expect(genTeacherCode(1)).toBe("GV0001"));
  test("mã giáo viên GV0042", () => expect(genTeacherCode(42)).toBe("GV0042"));
  test("mã lớp CNTT101.01 / .02", () => {
    expect(genClassCode("CNTT101", 1)).toBe("CNTT101.01");
    expect(genClassCode("CNTT101", 2)).toBe("CNTT101.02");
  });
});
